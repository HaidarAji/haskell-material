data Compass = North | East | South | West
  deriving (Eq, Ord, Enum, Show)
